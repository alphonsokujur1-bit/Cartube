package com.cartube.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout

/** A simple on-screen keyboard drawn on the car screen. */
class CarKeyboard(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onText(text: String)
        fun onBackspace()
        fun onEnter()
        fun onHide()
    }

    private val density = context.resources.displayMetrics.density
    private var shift = false
    private val letterKeys = mutableListOf<Button>()

    val view: LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(0xF0202124.toInt())
        val p = (4 * density).toInt()
        setPadding(p, p, p, p)
        isClickable = true // don't let taps fall through to the page
    }

    init {
        addRow(chars("1234567890"))
        addRow(chars("qwertyuiop"))
        addRow(chars("asdfghjkl"))
        addRow(listOf(SHIFT) + chars("zxcvbnm") + listOf(BACKSPACE))
        addRow(listOf(HIDE, ",", SPACE, ".", SEARCH))
    }

    private fun chars(s: String) = s.map { it.toString() }

    private fun addRow(keys: List<String>) {
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        keys.forEach { label ->
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight(label))
            val m = (2 * density).toInt()
            lp.setMargins(m, m, m, m)
            row.addView(makeKey(label), lp)
        }
        view.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun weight(label: String) = when (label) {
        SPACE -> 4f
        HIDE, SEARCH -> 1.6f
        SHIFT, BACKSPACE -> 1.4f
        else -> 1f
    }

    private fun makeKey(label: String): Button = Button(context).apply {
        text = label
        isAllCaps = false
        isFocusable = false
        textSize = if (label.length > 1) 16f else 20f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        setPadding(0, 0, 0, 0)
        stateListAnimator = null
        background = GradientDrawable().apply {
            cornerRadius = 8 * density
            setColor(if (label == SEARCH) 0xFF1A73E8.toInt() else 0xFF3C4043.toInt())
        }
        if (label.length == 1 && label[0].isLetter()) letterKeys.add(this)
        setOnClickListener { press(label) }
    }

    private fun press(label: String) {
        when (label) {
            SHIFT -> setShift(!shift)
            BACKSPACE -> listener.onBackspace()
            SPACE -> listener.onText(" ")
            HIDE -> listener.onHide()
            SEARCH -> listener.onEnter()
            else -> {
                listener.onText(if (shift) label.uppercase() else label)
                if (shift) setShift(false)
            }
        }
    }

    private fun setShift(on: Boolean) {
        shift = on
        letterKeys.forEach { b ->
            val t = b.text.toString()
            b.text = if (on) t.uppercase() else t.lowercase()
        }
    }

    companion object {
        const val SHIFT = "⇧"
        const val BACKSPACE = "⌫"
        const val SPACE = "space"
        const val HIDE = "Hide ⌄"
        const val SEARCH = "Search ↵"
    }
}
