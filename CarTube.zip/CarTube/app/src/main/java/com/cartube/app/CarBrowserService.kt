package com.cartube.app

import android.content.Intent
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/** Entry point that Android Auto connects to. */
class CarBrowserService : CarAppService() {

    // Personal sideloaded app: accept any Android Auto host.
    override fun createHostValidator(): HostValidator =
        HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = BrowserSession()
}

class BrowserSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen {
        val renderer = WebRenderer(carContext)
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(renderer)

        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                renderer.release()
            }
        })
        return BrowserScreen(carContext, renderer)
    }
}
