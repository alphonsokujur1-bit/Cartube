package com.cartube.app

import android.app.Activity
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

/**
 * Full-screen sign-in on the phone (with the phone's own keyboard).
 * Cookies are shared with the car screen, so the car uses the same account.
 */
class LoginActivity : Activity() {

    private lateinit var web: WebView
    private var announced = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this).apply {
            WebSetup.apply(this, desktopMode = false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val scheme = request.url.scheme ?: return true
                    return scheme != "http" && scheme != "https"
                }

                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    title = url ?: ""
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    CookieManager.getInstance().flush()
                    if (!announced && url != null && url.startsWith("https://m.youtube.com")) {
                        announced = true
                        Toast.makeText(
                            this@LoginActivity,
                            "Done. If you're signed in, press Back and reopen Car Tube in the car.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
        setContentView(web)
        web.loadUrl(LOGIN_URL)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val LOGIN_URL =
            "https://accounts.google.com/ServiceLogin?service=youtube&passive=true" +
                    "&continue=https%3A%2F%2Fm.youtube.com%2F"
    }
}
