package com.cartube.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.view.Display
import android.view.View
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/** A window shown on the car's virtual display that holds the WebView. */
class WebPresentation(
    outerContext: Context,
    display: Display,
    private val startUrl: String,
    private val prefs: Prefs
) : Presentation(outerContext, display) {

    /** Whole car screen (no padding). Fullscreen video goes here. */
    private var outer: FrameLayout? = null
    /** Normal pages, padded so Android Auto's buttons don't cover them. */
    private var pageArea: FrameLayout? = null
    private var webView: WebView? = null

    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val web = WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            if (prefs.desktopMode) settings.userAgentString = DESKTOP_USER_AGENT
            setBackgroundColor(Color.BLACK)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    // Keep http/https inside the browser; ignore app links (intent:, market:, etc.)
                    val scheme = request.url.scheme ?: return true
                    return scheme != "http" && scheme != "https"
                }
            }
            webChromeClient = ChromeClient()
        }

        val page = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            addView(web, matchParent())
        }
        val whole = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            addView(page, matchParent())
        }

        outer = whole
        pageArea = page
        webView = web
        setContentView(whole)
        web.loadUrl(startUrl)
    }

    private inner class ChromeClient : WebChromeClient() {

        // ---- Fullscreen video (YouTube etc.) -------------------------------
        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (fullscreenView != null) {
                callback.onCustomViewHidden()
                return
            }
            fullscreenView = view
            fullscreenCallback = callback
            view.setBackgroundColor(Color.BLACK)
            pageArea?.visibility = View.GONE
            outer?.addView(view, matchParent())
        }

        override fun onHideCustomView() {
            removeFullscreenView()
        }

        // Avoids the grey "play" placeholder before videos start.
        override fun getDefaultVideoPoster(): Bitmap =
            Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

        // ---- Microphone for websites ---------------------------------------
        override fun onPermissionRequest(request: PermissionRequest) {
            val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
            val micGranted = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
            if (wantsMic && prefs.micForWebsites && micGranted) {
                request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            } else {
                request.deny()
            }
        }
    }

    fun isFullscreen(): Boolean = fullscreenView != null

    /** Leaves fullscreen video. Returns true if it was in fullscreen. */
    fun exitFullscreen(): Boolean {
        if (fullscreenView == null) return false
        val cb = fullscreenCallback
        removeFullscreenView()
        cb?.onCustomViewHidden()
        return true
    }

    private fun removeFullscreenView() {
        fullscreenView?.let { outer?.removeView(it) }
        fullscreenView = null
        fullscreenCallback = null
        pageArea?.visibility = View.VISIBLE
    }

    /** Keeps normal pages inside the area not covered by Android Auto's own UI. */
    fun applyContentArea(area: Rect, width: Int, height: Int) {
        if (prefs.fullCarScreen) {
            pageArea?.setPadding(0, 0, 0, 0)
            return
        }
        pageArea?.setPadding(
            area.left.coerceAtLeast(0),
            area.top.coerceAtLeast(0),
            (width - area.right).coerceAtLeast(0),
            (height - area.bottom).coerceAtLeast(0)
        )
    }

    fun web(): WebView? = webView

    fun currentUrl(): String? = webView?.url

    fun destroyWeb() {
        exitFullscreen()
        webView?.apply {
            stopLoading()
            destroy()
        }
        webView = null
    }

    private fun matchParent() = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    )

    companion object {
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
    }
}
