package com.cartube.app

import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/**
 * Main car screen. YouTube's mobile site fills the background (drawn by [WebRenderer]);
 * this template adds car-sized buttons on top.
 *
 * Android Auto buttons : Menu, Pan (kept minimal)
 * Own control bar      : opens with three quick taps on the screen
 */
class BrowserScreen(
    carContext: CarContext,
    private val renderer: WebRenderer
) : Screen(carContext) {

    private val prefs = Prefs(carContext)
    private val voice = VoiceSearch(carContext)

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) = voice.stop()
        })
    }

    init {
        renderer.onMic = { startVoiceSearch() }
        renderer.onMenu = { openMenu() }
    }

    override fun onGetTemplate(): Template {
        // Android Auto always shows its own buttons when the screen is tapped,
        // so we keep them to the minimum: one Menu button and the Pan button.
        // All other controls are on our own bar that opens with a triple tap.
        val actionStrip = ActionStrip.Builder()
            .addAction(iconAction(R.drawable.ic_menu) { openMenu() })
            .build()

        val mapStrip = ActionStrip.Builder()
            .addAction(Action.PAN)
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actionStrip)
            .setMapActionStrip(mapStrip)
            .setPanModeListener { /* scrolling goes to the page */ }
            .build()
    }

    private fun openMenu() {
        if (screenManager.top !is BrowserScreen) return
        screenManager.push(
            UrlScreen(
                carContext,
                onOpen = { input -> renderer.load(input) },
                onVoice = { startVoiceSearch() },
                onReload = { renderer.reload() },
                onShowControls = { renderer.showControls() },
                onShowKeyboard = { renderer.showKeyboard() }
            )
        )
    }

    private fun startVoiceSearch() {
        toast("Listening… say what to search on YouTube")
        voice.start(
            prefs.voiceLanguage,
            onResult = { text ->
                toast("Searching: $text")
                renderer.search(text)
            },
            onError = { message -> toast(message) }
        )
    }

    private fun toast(message: String) {
        CarToast.makeText(carContext, message, CarToast.LENGTH_LONG).show()
    }

    private fun iconAction(iconRes: Int, onClick: () -> Unit): Action =
        Action.Builder()
            .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, iconRes)).build())
            .setOnClickListener { onClick() }
            .build()
}
