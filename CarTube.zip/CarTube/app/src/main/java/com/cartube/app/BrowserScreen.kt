package com.cartube.app

import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/**
 * Main car screen. YouTube's mobile site fills the background (drawn by [WebRenderer]);
 * this template adds car-sized buttons on top.
 *
 * Top strip  : Back, Mic (voice search), Search / menu, Play-Pause
 * Side strip : Rewind 10 s, Forward 10 s, Full screen, Pan (drag to scroll)
 */
class BrowserScreen(
    carContext: CarContext,
    private val renderer: WebRenderer
) : Screen(carContext) {

    private val prefs = Prefs(carContext)
    private val voice = VoiceSearch(carContext)

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) = voice.stop()
        })
    }

    override fun onGetTemplate(): Template {
        val actionStrip = ActionStrip.Builder()
            .addAction(iconAction(R.drawable.ic_back) { renderer.goBack() })
            .addAction(iconAction(R.drawable.ic_mic) { startVoiceSearch() })
            .addAction(iconAction(R.drawable.ic_search) {
                screenManager.push(
                    UrlScreen(
                        carContext,
                        onOpen = { input -> renderer.load(input) },
                        onVoice = { startVoiceSearch() },
                        onReload = { renderer.reload() },
                        onPageUp = { renderer.pageUp() },
                        onPageDown = { renderer.pageDown() }
                    )
                )
            })
            .addAction(iconAction(R.drawable.ic_play_pause) { renderer.playPause() })
            .build()

        val mapStrip = ActionStrip.Builder()
            .addAction(iconAction(R.drawable.ic_rewind) { renderer.seek(-10) })
            .addAction(iconAction(R.drawable.ic_fast_forward) { renderer.seek(10) })
            .addAction(iconAction(R.drawable.ic_fullscreen) { renderer.toggleFullscreen() })
            .addAction(Action.PAN)
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actionStrip)
            .setMapActionStrip(mapStrip)
            .setPanModeListener { /* scrolling goes to the page */ }
            .build()
    }

    private fun startVoiceSearch() {
        toast("Listening… say what to search on YouTube")
        voice.start(
            prefs.voiceLanguage,
            onResult = { text ->
                toast("Searching: $text")
                renderer.search(text)
            },
            onError = { message -> toast(message) }
        )
    }

    private fun toast(message: String) {
        CarToast.makeText(carContext, message, CarToast.LENGTH_LONG).show()
    }

    private fun iconAction(iconRes: Int, onClick: () -> Unit): Action =
        Action.Builder()
            .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, iconRes)).build())
            .setOnClickListener { onClick() }
            .build()
}
