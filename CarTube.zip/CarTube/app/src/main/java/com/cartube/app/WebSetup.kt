package com.cartube.app

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

/** Shared WebView settings for the car screen and the phone sign-in screen. */
object WebSetup {

    const val DESKTOP_USER_AGENT =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

    /**
     * Makes the WebView identify itself like the normal Chrome app
     * (removes the "wv" / "Version/4.0" in-app markers), which Google's
     * sign-in page checks.
     */
    fun chromeLikeUserAgent(default: String): String =
        default.replace("; wv", "")
            .replace(Regex(" Version/\\d+(\\.\\d+)*"), "")

    @SuppressLint("SetJavaScriptEnabled", "RequiresFeature")
    fun apply(web: WebView, desktopMode: Boolean) {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.javaScriptCanOpenWindowsAutomatically = true
        s.userAgentString =
            if (desktopMode) DESKTOP_USER_AGENT else chromeLikeUserAgent(s.userAgentString)

        // Stop sending the "X-Requested-With: <app>" header where supported.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, emptySet())
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
    }
}
