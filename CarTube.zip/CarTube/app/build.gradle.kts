plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cartube.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.cartube.app"
        minSdk = 26          // Android 8.0 and newer (works on Android 14)
        targetSdk = 34       // Android 14
        versionCode = 2
        versionName = "1.1"
    }

    // Fixed key, so future versions install as updates over this one
    // (no need to uninstall first).
    signingConfigs {
        create("fixed") {
            storeFile = file("cartube.jks")
            storePassword = "cartube123"
            keyAlias = "cartube"
            keyPassword = "cartube123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.car.app:app:1.4.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
