# Car Tube v1.1 — watch YouTube videos on Android Auto

Car Tube shows YouTube's own mobile website (m.youtube.com) on the car screen,
with large buttons for the car. Works on Android 8.0–15 phones (including Android 14).
Use only while parked.

## New in v1.1
- On-screen keyboard on the car screen: opens when you tap a search box
- Sign in to YouTube from the phone (Car Tube on phone → Sign in to YouTube)
- Controls open with 3 quick taps; Android Auto shows only Menu + Pan buttons

## Car buttons (old v1.0 layout below, now on the triple-tap bar)
Top: **Back** (also leaves fullscreen) · **🎤 Voice search** · **🔍 Search/Menu** · **Play/Pause**
Side: **Rewind 10s** · **Forward 10s** · **Full screen** · **Pan** (drag to scroll)

The 🔍 menu has: Voice search, Home, Subscriptions, History, You/Library,
Page up, Page down and Reload. Typing a search works only while parked.

## Phone settings (open Car Tube on the phone)
- Allow microphone (needed for 🎤)
- Voice language: English (India), Hindi or Marathi
- Use the whole car screen
- Desktop mode (leave off for YouTube)

## Notes
- Signing in to a Google account may be blocked inside this app. Videos work without signing in.
- Video plays only while Car Tube is on the car screen.
- Install with KingInstaller (Shizuku), just like Car Browser.
