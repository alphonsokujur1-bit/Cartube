package com.carcinema.app

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.Row
import androidx.car.app.model.SearchTemplate
import androidx.car.app.model.Template

/**
 * Search screen + menu: type a search with the car keyboard (while parked),
 * use voice search, or jump to a Netflix section.
 */
class UrlScreen(
    carContext: CarContext,
    private val onOpen: (String) -> Unit,
    private val onVoice: () -> Unit,
    private val onReload: () -> Unit,
    private val onShowControls: () -> Unit,
    private val onShowKeyboard: () -> Unit
) : Screen(carContext) {

    private val sections = listOf(
        "🏠 Home" to "https://www.netflix.com/browse",
        "➕ My List" to "https://www.netflix.com/browse/my-list",
        "🔍 Search page" to "https://www.netflix.com/search",
        "👤 Switch profile" to "https://www.netflix.com/ProfilesGate"
    )

    override fun onGetTemplate(): Template {
        val list = ItemList.Builder()
        list.addItem(actionRow("🎤 Voice search", "Tap and say what to watch", onVoice))

        sections.forEach { (name, url) ->
            list.addItem(
                Row.Builder()
                    .setTitle(name)
                    .addText("Open")
                    .setOnClickListener { open(url) }
                    .build()
            )
        }

        list.addItem(actionRow("🎛 Show controls", "Or tap the screen 3 times quickly", onShowControls))
        list.addItem(actionRow("⌨ Show keyboard", "Type on the car screen", onShowKeyboard))
        list.addItem(actionRow("⟳ Reload", "Reload the page", onReload))

        return SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchSubmitted(searchText: String) {
                if (searchText.isNotBlank()) open(searchText)
            }
        })
            .setHeaderAction(Action.BACK)
            .setSearchHint("Search films and shows")
            .setShowKeyboardByDefault(false)
            .setItemList(list.build())
            .build()
    }

    private fun actionRow(title: String, text: String, action: () -> Unit) =
        Row.Builder()
            .setTitle(title)
            .addText(text)
            .setOnClickListener {
                screenManager.pop()
                action()
            }
            .build()

    private fun open(input: String) {
        onOpen(input)
        screenManager.pop()
    }
}
