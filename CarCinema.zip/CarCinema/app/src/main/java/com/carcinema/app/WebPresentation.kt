package com.carcinema.app

import android.Manifest
import android.app.Presentation
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import org.json.JSONObject

/**
 * The window shown on the car screen. Layers, bottom to top:
 *   page (WebView) → fullscreen video → control bar (triple tap) → keyboard
 */
class WebPresentation(
    outerContext: Context,
    display: Display,
    private val startUrl: String,
    private val prefs: Prefs,
    private val controls: List<Pair<Int, () -> Unit>>
) : Presentation(outerContext, display) {

    private val main = Handler(Looper.getMainLooper())
    private val density get() = context.resources.displayMetrics.density

    private var outer: FrameLayout? = null
    private var pageArea: FrameLayout? = null
    private var webView: WebView? = null
    private var controlBar: LinearLayout? = null
    private var keyboard: CarKeyboard? = null

    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var area: Rect? = null

    private val hideControls = Runnable { controlBar?.visibility = View.GONE }
    private val hideKeyboardRunnable = Runnable { keyboard?.view?.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val web = WebView(context).apply {
            WebSetup.apply(this, prefs.desktopMode)
            setBackgroundColor(Color.BLACK)
            addJavascriptInterface(KeyboardBridge(), "CarTubeKb")

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val scheme = request.url.scheme ?: return true
                    return scheme != "http" && scheme != "https"
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    view.evaluateJavascript(FOCUS_WATCH_JS, null)
                }
            }
            webChromeClient = ChromeClient()
        }

        val page = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            addView(web, matchParent())
        }
        val whole = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            addView(page, matchParent())
        }

        // Control bar (hidden until triple tap)
        val bar = buildControlBar()
        whole.addView(
            bar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (64 * density).toInt(),
                Gravity.BOTTOM
            )
        )

        // On-screen keyboard (hidden until a text box is tapped)
        val kb = CarKeyboard(context, KeyboardActions())
        kb.view.visibility = View.GONE
        whole.addView(
            kb.view,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (context.resources.displayMetrics.heightPixels * 0.48f).toInt(),
                Gravity.BOTTOM
            )
        )

        outer = whole
        pageArea = page
        webView = web
        controlBar = bar
        keyboard = kb
        setContentView(whole)
        web.loadUrl(startUrl)
    }

    // ---- Control bar ----------------------------------------------------------

    private fun buildControlBar(): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        setBackgroundColor(0xDD000000.toInt())
        visibility = View.GONE
        isClickable = true
        controls.forEach { (icon, action) ->
            addView(ImageView(context).apply {
                setImageResource(icon)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                val p = (12 * density).toInt()
                setPadding(p, p, p, p)
                isFocusable = false
                setOnClickListener {
                    action()
                    scheduleHideControls()
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
    }

    fun showControls() {
        val bar = controlBar ?: return
        bar.visibility = View.VISIBLE
        bar.bringToFront()
        keyboard?.view?.bringToFront()
        scheduleHideControls()
    }

    fun hideControlsNow() {
        main.removeCallbacks(hideControls)
        controlBar?.visibility = View.GONE
    }

    private fun scheduleHideControls() {
        main.removeCallbacks(hideControls)
        main.postDelayed(hideControls, 7000)
    }

    // ---- Keyboard -------------------------------------------------------------

    private inner class KeyboardBridge {
        @JavascriptInterface
        fun focus(editable: Boolean) {
            main.post { if (editable) showKeyboard() else hideKeyboardSoon() }
        }
    }

    fun showKeyboard() {
        main.removeCallbacks(hideKeyboardRunnable)
        val v = keyboard?.view ?: return
        v.visibility = View.VISIBLE
        v.bringToFront()
    }

    fun toggleKeyboard() {
        val v = keyboard?.view ?: return
        if (v.visibility == View.VISIBLE) v.visibility = View.GONE else showKeyboard()
    }

    private fun hideKeyboardSoon() {
        main.removeCallbacks(hideKeyboardRunnable)
        main.postDelayed(hideKeyboardRunnable, 400)
    }

    private inner class KeyboardActions : CarKeyboard.Listener {
        override fun onText(text: String) {
            webView?.evaluateJavascript(
                "document.execCommand('insertText',false,${JSONObject.quote(text)})", null
            )
        }

        override fun onBackspace() {
            webView?.evaluateJavascript("document.execCommand('delete',false,null)", null)
        }

        override fun onEnter() {
            val web = webView ?: return
            val before = web.url
            web.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            web.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
            // If Enter did nothing, submit the search form directly.
            main.postDelayed({
                if (webView?.url == before) webView?.evaluateJavascript(SUBMIT_JS, null)
            }, 500)
            keyboard?.view?.visibility = View.GONE
        }

        override fun onHide() {
            keyboard?.view?.visibility = View.GONE
        }
    }

    // ---- Web page events ------------------------------------------------------

    private inner class ChromeClient : WebChromeClient() {

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (fullscreenView != null) {
                callback.onCustomViewHidden()
                return
            }
            fullscreenView = view
            fullscreenCallback = callback
            view.setBackgroundColor(Color.BLACK)
            pageArea?.visibility = View.GONE
            outer?.addView(view, 1, matchParent()) // above page, below controls/keyboard
        }

        override fun onHideCustomView() {
            removeFullscreenView()
        }

        override fun getDefaultVideoPoster(): Bitmap =
            Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

        override fun onPermissionRequest(request: PermissionRequest) {
            // Netflix videos are copy-protected (Widevine DRM): allow protected playback.
            if (request.resources.contains(PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID)) {
                request.grant(arrayOf(PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID))
                return
            }
            val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
            val micGranted = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
            if (wantsMic && prefs.micForWebsites && micGranted) {
                request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            } else {
                request.deny()
            }
        }
    }

    fun exitFullscreen(): Boolean {
        if (fullscreenView == null) return false
        val cb = fullscreenCallback
        removeFullscreenView()
        cb?.onCustomViewHidden()
        return true
    }

    private fun removeFullscreenView() {
        fullscreenView?.let { outer?.removeView(it) }
        fullscreenView = null
        fullscreenCallback = null
        pageArea?.visibility = View.VISIBLE
    }

    /** Keeps pages and the control bar clear of Android Auto's own buttons. */
    fun applyContentArea(area: Rect, width: Int, height: Int) {
        this.area = Rect(area)
        val left = area.left.coerceAtLeast(0)
        val top = area.top.coerceAtLeast(0)
        val right = (width - area.right).coerceAtLeast(0)
        val bottom = (height - area.bottom).coerceAtLeast(0)

        if (prefs.fullCarScreen) pageArea?.setPadding(0, 0, 0, 0)
        else pageArea?.setPadding(left, top, right, bottom)

        (controlBar?.layoutParams as? FrameLayout.LayoutParams)?.let {
            it.setMargins(left, 0, right, bottom)
            controlBar?.layoutParams = it
        }
    }

    fun web(): WebView? = webView

    /** Sends a real key press to the page (Netflix player: space, arrows, F). */
    fun sendKey(keyCode: Int) {
        val web = webView ?: return
        web.requestFocus()
        web.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        web.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    fun currentUrl(): String? = webView?.url

    fun destroyWeb() {
        main.removeCallbacksAndMessages(null)
        exitFullscreen()
        webView?.apply {
            stopLoading()
            destroy()
        }
        webView = null
    }

    private fun matchParent() = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    )

    companion object {
        /** Tells the app when a text box on the page gets or loses focus. */
        private const val FOCUS_WATCH_JS = """
(function(){
  if(window.__ctkb)return; window.__ctkb=1;
  function ed(e){
    if(!e)return false;
    var t=(e.tagName||'').toLowerCase();
    if(t=='textarea')return true;
    if(t=='input'){var ty=(e.type||'text').toLowerCase();
      return ['text','search','email','url','tel','password','number'].indexOf(ty)>=0;}
    return !!e.isContentEditable;
  }
  document.addEventListener('focusin',function(e){ if(ed(e.target)) CarTubeKb.focus(true); },true);
  document.addEventListener('focusout',function(){
    setTimeout(function(){ if(!ed(document.activeElement)) CarTubeKb.focus(false); },300);
  },true);
  if(ed(document.activeElement)) CarTubeKb.focus(true);
})();"""

        private const val SUBMIT_JS = """
(function(){
  var e=document.activeElement;
  if(e&&e.form){ if(e.form.requestSubmit)e.form.requestSubmit(); else e.form.submit(); return; }
  if(e&&e.value){ location.href='https://www.netflix.com/search?q='+encodeURIComponent(e.value); }
})();"""
    }
}
