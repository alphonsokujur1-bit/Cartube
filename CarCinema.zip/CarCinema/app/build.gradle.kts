plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.carcinema.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.carcinema.app"
        minSdk = 26          // Android 8.0 and newer (works on Android 14)
        targetSdk = 34       // Android 14
        versionCode = 1
        versionName = "1.0"
    }

    // Fixed key, so future versions install as updates over this one
    // (no need to uninstall first).
    signingConfigs {
        create("fixed") {
            storeFile = file("carcinema.jks")
            storePassword = "carcinema123"
            keyAlias = "carcinema"
            keyPassword = "carcinema123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.car.app:app:1.4.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
