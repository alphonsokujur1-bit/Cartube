# Car Cinema v1.0 — Netflix website on Android Auto

Car Cinema shows the Netflix website (www.netflix.com) on the car screen.
Works on Android 8.0–15 phones (including Android 14). Use only while parked.
You need your own Netflix subscription.

## Features
- **Sign in on the phone:** open Car Cinema on the phone → "Sign in to Netflix".
  The car screen then uses the same account.
- **Car keyboard:** opens when you tap a search box (or ☰ → Show keyboard)
- **Triple tap** the screen → control bar: Back, Home, Mic, Keyboard,
  ⏪ 10 s, ⏯, ⏩ 10 s, Full screen, Page up/down, Menu, Close
- **Full screen:** ⛶ on the bar, or Netflix's own full-screen button
- **🎤 Voice search:** say a film or show name
- ☰ menu: Home, My List, Search page, Switch profile

## Important
Netflix videos are copy-protected (DRM). On some phones or cars the video
may stay black or show an error code. Browsing, menus and sign-in still work.
Desktop mode is ON by default, because Netflix's mobile website only offers
to open the Netflix app.
